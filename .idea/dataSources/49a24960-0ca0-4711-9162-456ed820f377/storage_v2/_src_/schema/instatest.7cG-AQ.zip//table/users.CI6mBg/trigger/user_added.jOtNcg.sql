create trigger user_added
  after INSERT
  on users
  for each row
  INSERT INTO user_settings (id) VALUES (NEW.id);

